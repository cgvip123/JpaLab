package com.cg_vip.lab1.dao;

public interface Querymapper 
{
	String SELECT_QUERY = "SELECT * FROM";
	String  DELETE_QUERY = "DELETE FROM b WHERE id IN (SELECT id FROM a)";
}
