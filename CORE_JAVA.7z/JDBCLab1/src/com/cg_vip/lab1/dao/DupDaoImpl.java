package com.cg_vip.lab1.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.cg_vip.lab1.util.DBAUtil;

public class DupDaoImpl implements IDupDao
{
	Connection con = null;
	PreparedStatement pStatement = null;

	@Override
	public ResultSetMetaData selectMetaData(String tableName) throws SQLException, IOException
	{
		if(con==null)
		{
			con = DBAUtil.getConnection();
		}
		pStatement = con.prepareStatement(Querymapper.SELECT_QUERY+" "+tableName);
	
		ResultSet rs = pStatement.executeQuery();
		ResultSetMetaData rsMeta = rs.getMetaData();
		return rsMeta;
	}

	@Override
	public ResultSet select(String tableName) throws SQLException, IOException 
	{
		if(con==null)
		{
			con = DBAUtil.getConnection();
		}
		
		pStatement = con.prepareStatement(Querymapper.SELECT_QUERY+" "+tableName);
		
		ResultSet rs = pStatement.executeQuery();
		return rs;
	}
	
	@Override
	public boolean remDuplicate(String tableName1,String tableName2) throws SQLException, IOException 
	{
		if(con==null)
		{
			con = DBAUtil.getConnection();
		}
			pStatement = con.prepareStatement(Querymapper.DELETE_QUERY);
			
			int done = pStatement.executeUpdate();
			if(done==1)
			{
				return true;
			}
			return false;
		
	}
}
		
