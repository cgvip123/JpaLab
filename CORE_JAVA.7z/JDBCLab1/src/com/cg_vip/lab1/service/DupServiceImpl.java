package com.cg_vip.lab1.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.cg_vip.lab1.dao.DupDaoImpl;
import com.cg_vip.lab1.dao.IDupDao;

public class DupServiceImpl implements IDupService
{
	
	IDupDao iDupDao = new DupDaoImpl(); 
	@Override
	public ResultSetMetaData selectMetaData(String tableName) throws SQLException, IOException 
	{
		return iDupDao.selectMetaData(tableName);
	}
	
	@Override
	public ResultSet select(String tableName) throws SQLException, IOException 
	{
		return iDupDao.select(tableName);
	}
	
	@Override
	public boolean remDuplicate(String tableName1,String tableName2) throws SQLException, IOException
	{
		return iDupDao.remDuplicate(tableName1,tableName2);
	}
}
