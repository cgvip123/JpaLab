package com.cg_vip.lab1.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public interface IDupService 
{
	ResultSetMetaData selectMetaData(String tableName) throws SQLException, IOException;
	ResultSet select(String tableName) throws SQLException, IOException;
	boolean remDuplicate(String tableName1,String tableName2) throws SQLException, IOException;
}
