package com.cg_vip.lab1.ui;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg_vip.lab1.dao.Querymapper;
import com.cg_vip.lab1.service.DupServiceImpl;
import com.cg_vip.lab1.service.IDupService;

public class Main {

	public static void main(String[] args)
	{
		int choice;
		Scanner scanner = new Scanner(System.in);
		IDupService iDupSer = new DupServiceImpl();
		System.out.println("================WELCOME================");
		
		while(true)
		{
			System.out.println("1. DISPLAY DATA      2. DELETE DUPLICATE     3. EXIT");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();
			switch(choice)
			{
				case 1: System.out.println("Enter table name");
						String tableName = scanner.next();
						try 
						{
							
							ResultSetMetaData metaData = iDupSer.selectMetaData(tableName);
							ResultSet results = iDupSer.select(tableName);
							System.out.println(metaData.getColumnName(1)+"     "+metaData.getColumnName(2));
							while(results.next())
							{
								System.out.println(results.getInt(1)+"     "+results.getString(2));
							}
						} 
						catch (SQLException | IOException e) 
						{
							e.printStackTrace();
						}
						break;
				case 2: System.out.println("Enter table 1 name");
						String table1 = scanner.next();
						System.out.println("Enter table 2 name");
						String table2 = scanner.next();
						try {
							iDupSer.remDuplicate(table1, table2);
						} catch (SQLException | IOException e1)
						{
							e1.printStackTrace();
						}
						break;
					
				case 3: System.out.println("+++++++++++++++++++++++++++++++++++");
						System.exit(0);
			}
		}
	}

}
