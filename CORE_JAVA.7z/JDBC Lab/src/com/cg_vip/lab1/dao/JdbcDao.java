package com.cg_vip.lab1.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcDao implements IJdbcDao 
{
	Connection connection = null;
	PreparedStatement pStatement = null;
	ResultSet rs = null;		
	
	@Override
	public ResultSet selectData(String tableName) throws SQLException 
	{
		pStatement = connection.prepareStatement(QueryMapper.SELECT_QUERY);
		pStatement.setString(1,tableName);
		rs = pStatement.executeQuery();
		return rs;
	}

	@Override
	public int deleteDuplicateData(String table1, String table2) 
	{
		pStatement=connection.prepareStatement(QueryMapper)
		return 0;
	}
	
}
