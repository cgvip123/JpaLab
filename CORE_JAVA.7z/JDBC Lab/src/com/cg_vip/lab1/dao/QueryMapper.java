package com.cg_vip.lab1.dao;

public interface QueryMapper
{
	public static final String DELETE_DUPLICATE_QUERY="DELETE FROM ? WHERE id IN (SELECT id FROM ?)";
	public static final String SELECT_QUERY="SELECT * FROM ?";
}
