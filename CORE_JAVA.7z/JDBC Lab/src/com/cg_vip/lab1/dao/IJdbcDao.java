package com.cg_vip.lab1.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface IJdbcDao 
{
	ResultSet selectData(String tableName) throws SQLException;
	int deleteDuplicateData(String table1,String table2);
}
