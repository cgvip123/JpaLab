package com.cg_vip.lab1.service;

import java.sql.ResultSet;

public interface IJdbcService 
{
	ResultSet selectData(String tableName);
	int deleteDuplicateData(String table1,String table2);
}
