package com.cg_vip.lab1.service;

import java.sql.ResultSet;

public class JdbcService implements IJdbcService
{

	@Override
	public ResultSet selectData(String tableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteDuplicateData(String table1, String table2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
