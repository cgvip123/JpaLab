package com.cg_vip.ems.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg_vip.ems.dto.Authors;

public interface IAuthorDao
{
	public boolean addAuthor(Authors auth);
	public Authors deleteAuth(int auth_id);
	public ArrayList<Authors> getAuthor();
	Authors updateAuth(int auth_id, String firstName, String MiddleName, String LastName);
	
}
