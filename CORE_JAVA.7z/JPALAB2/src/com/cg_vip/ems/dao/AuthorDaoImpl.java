package com.cg_vip.ems.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg_vip.ems.dto.Authors;
import com.cg_vip.ems.util.JPAUtil;

public class AuthorDaoImpl implements IAuthorDao
{
	EntityManager em = JPAUtil.geEntityManager();
	EntityTransaction entityTran = em.getTransaction();
	@Override
	public boolean addAuthor(Authors auth)
	{
		entityTran.begin();
		em.persist(auth);
		entityTran.commit();
		return true;
	}

	@Override
	public Authors deleteAuth(int auth_id) 
	{
		entityTran.begin();
		Authors author = em.find(Authors.class,auth_id);
		em.remove(author);
		entityTran.commit();
		return author;
	}

	@Override
	public ArrayList<Authors> getAuthor() 
	{
		String selAllQuery = "SELECT auths FROM Authors auths";
		TypedQuery<Authors> authList = em.createQuery(selAllQuery,Authors.class);
		return (ArrayList<Authors>) authList.getResultList();
	}

	@Override
	public Authors updateAuth(int auth_id, String firstName,String middleName,String lastName) 
	{
		entityTran.begin();
		Authors author1 = em.find(Authors.class,auth_id);
		author1.setFirstName(firstName);
		author1.setMiddleName(middleName);
		author1.setLastName(lastName);
		em.merge(author1);
		return author1;
	}


}
