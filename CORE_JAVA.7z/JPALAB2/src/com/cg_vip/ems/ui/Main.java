package com.cg_vip.ems.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg_vip.ems.dto.Authors;
import com.cg_vip.ems.service.AuthorServiceImpl;
import com.cg_vip.ems.service.IAuthorService;

public class Main
{
	public static void main(String[] args)
	{
		IAuthorService iAuthorSer = new AuthorServiceImpl();
		Authors auth = new Authors();
		Scanner scanner = new Scanner(System.in);
		while(true)
		{
			System.out.println("1. Add Author   2. Update Author  3. Delete Author 4. Display Authors");
			int choice;
			System.out.println("Enter Choice");
			choice = scanner.nextInt();
			switch(choice)
			{
				case 1: System.out.println("Enter First Name");
						String firstName=scanner.next();
						System.out.println("Enter Middle Name");
						String middleName=scanner.next();
						System.out.println("Enter Last Name");
						String lastName=scanner.next();
						System.out.println("Enter Phone No");
						String phoneNo=scanner.next();
						
						auth.setFirstName(firstName);
						auth.setMiddleName(middleName);
						auth.setLastName(lastName);
						auth.setPhoneNo(phoneNo);
						System.out.println("================Added================");
						boolean done = iAuthorSer.addAuthor(auth);
						System.out.println("================"+done+"================");
						System.out.println("========================================");
						break;
					
				case 2: System.out.println("Enter Author Id To Update");
						int auth_id = scanner.nextInt();
						System.out.println("Enter Author First Name To Set");
						String auth_name = scanner.next();
						System.out.println("Enter Author Middle Name To Set");
						String  midName = scanner.next();
						System.out.println("Enter Author Last Name To Set");
						String lasName = scanner.next();
						System.out.println("==================================UPDATED==========================");
						Authors auth1 = iAuthorSer.updateAuth(auth_id, auth_name,midName,lasName);
						System.out.println(auth1);
						System.out.println("===================================================================");
						break;
				
				case 3: System.out.println("Enter Author Id");
						int author = scanner.nextInt();
						System.out.println("==================================DELETED==========================");
						iAuthorSer.deleteAuth(author);
						System.out.println("==================================================================");
						break;
				
				case 4: System.out.println("==================================DISPLAY==========================");
						List<Authors> list = new ArrayList<>();
						list = iAuthorSer.getAuthor();
						for(Authors auth2:list)
						{
							System.out.println(auth2);
						}
						System.out.println("==================================================================");		
						break;
				
				case 5: System.out.println("====================Thank YOU===================");
						System.exit(0);
			}
		}
				
		
	}

}
