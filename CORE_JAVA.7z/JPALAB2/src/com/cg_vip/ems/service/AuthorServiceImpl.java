package com.cg_vip.ems.service;

import java.util.ArrayList;

import com.cg_vip.ems.dao.AuthorDaoImpl;
import com.cg_vip.ems.dao.IAuthorDao;
import com.cg_vip.ems.dto.Authors;

public class AuthorServiceImpl implements IAuthorService
{
	IAuthorDao iAuthDao = new AuthorDaoImpl();

	@Override
	public boolean addAuthor(Authors auth)
	{
		
		return iAuthDao.addAuthor(auth);
	}

	@Override
	public Authors deleteAuth(int auth_id)
	{
		
		return iAuthDao.deleteAuth(auth_id);
	}

	@Override
	public ArrayList<Authors> getAuthor() 
	{
		
		return iAuthDao.getAuthor();
	}

	@Override
	public Authors updateAuth(int auth_id, String firstName,String MiddleName,String LastName)
	{
		
		return iAuthDao.updateAuth(auth_id, firstName,MiddleName,LastName);
	}
 	
	
}
