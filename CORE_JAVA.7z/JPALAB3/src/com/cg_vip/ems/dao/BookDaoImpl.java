package com.cg_vip.ems.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg_vip.ems.dto.Authors;
import com.cg_vip.ems.dto.Book;
import com.cg_vip.ems.util.JPAUtil;

public class BookDaoImpl implements IBookDao
{
	EntityManager em = JPAUtil.geEntityManager();
	EntityTransaction entityTran = em.getTransaction();
	public void addBook() {
		Authors author=new Authors();
		author.setName("Brajesh");

		Book book2= new Book();
		book2.setName("ABC");
		book2.setPrice(1000);
		
		Book book1= new Book();
		book1.setName("ABC");
		book1.setPrice(1000);
		
		List<Book> list=new ArrayList<Book>();
		list.add(book1);
		list.add(book2);
		
		author.setBooks(list);
		
		entityTran.begin();
		em.persist(author);
		entityTran.commit();
	}
	@Override
	public ArrayList<Book> getBook() 
	{
		String selAllQuery = "Select book From Book book";
		TypedQuery<Book> tq = em.createQuery(selAllQuery, Book.class);
		List<Book> bookList = tq.getResultList();
		
		return (ArrayList<Book>) bookList;
	}
	@Override
	public ArrayList<Book> getBookByAuthorName(String authorName) 
	{
		String selAllQuery = "SELECT title FROM Book WHERE isbn IN(SELECT book FROM book_author_table book WHERE author = (SELECT id FROM author WHERE name= "+authorName+"))";
		TypedQuery<Book> tq1 = em.createQuery(selAllQuery, Book.class);
		List<Book> bookList1 = tq1.getResultList();
		return (ArrayList<Book>) bookList1;
	}
	@Override
	public ArrayList<Book> getBookByPriceRange(double min, double max) 
	{
		String selAllQuery = "SELECT title FROM Book WHERE price BETWEEN "+min+" AND"+max;
		TypedQuery<Book> tq2 = em.createQuery(selAllQuery, Book.class);
		List<Book> bookList3 = tq2.getResultList();
		return (ArrayList<Book>) bookList3;
	}
}
