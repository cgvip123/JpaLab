package com.cg_vip.ems.dao;

import java.util.ArrayList;

import com.cg_vip.ems.dto.Book;

public interface IBookDao
{
	public void addBook() ;
	public ArrayList<Book> getBook();
	public ArrayList<Book> getBookByAuthorName(String authorName);
	public ArrayList<Book> getBookByPriceRange(double min,double max);
	
}
