package com.cg_vip.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg_vip.ems.dto.Book;
import com.cg_vip.ems.service.BookServiceImpl;
import com.cg_vip.ems.service.IBookService;

public class Main
{
	public static void main(String[] args)
	{
		IBookService iBookSer = new BookServiceImpl();


		iBookSer.addBook();

		Scanner scanner = new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Display Books  2.Display By Author Name 3.Display By Price Range 4.Exit ");
			int choice;
			System.out.println("Enter Choice");
			choice = scanner.nextInt();
			switch(choice)
			{
				case 1: System.out.println("================DISPLAY================");
						ArrayList<Book> lis = iBookSer.getBook();
						for(Book book: lis)
						{
							System.out.println(book);
						}
						System.out.println("========================================");
						break;
					
				case 2: System.out.println("Enter Author Name");
						String auth_name = scanner.next();
						System.out.println("==================================Books For Author:"+auth_name+"==========================");
						ArrayList<Book> bList = iBookSer.getBookByAuthorName(auth_name);
						for(Book book: bList)
						{
							System.out.println(book);
						}
						System.out.println("===================================================================");
						break;
				
				case 3: System.out.println("Enter Min Range");
						double min = scanner.nextDouble();
						System.out.println("Enter Max Range");
						double max = scanner.nextDouble();
						 System.out.println("================BOOKS BETWEEN "+min+" AND"+max+"================");
						ArrayList<Book> list = iBookSer.getBookByPriceRange(min, max);
						for(Book book: list)
						{
							System.out.println(book);
						}
						System.out.println("========================================");
						break;
				
				case 4: System.out.println("====================Thank YOU===================");
						System.exit(0);
		
			}
		}
				
		
	}

}
