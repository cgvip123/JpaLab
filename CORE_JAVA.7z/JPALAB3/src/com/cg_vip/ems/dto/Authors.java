package com.cg_vip.ems.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Authors
{	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id",length=10)
	private int authorId;
	@Column(name="name",length=20)
	private String name;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinTable(name="book_author_table",joinColumns={@JoinColumn(name="id")}
									   ,inverseJoinColumns={@JoinColumn(name="isbn")})
	private List<Book> books;
	
	public Authors()
	{
		super();
		
	}

	
	public int getAuthorId() {
		return authorId;
	}



	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public List<Book> getBooks() {
		return books;
	}



	public void setBooks(List<Book> books) {
		this.books = books;
	}



	@Override
	public String toString() {
		return "Authors [authorId=" + authorId + ", Name=" + name + ", books=" + books + "]";
	}
	
	
}
