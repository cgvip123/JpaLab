package com.cg_vip.ems.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="Book")
public class Book 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="isbn",length=10)
	private int isbn;
	
	@Column(name="name",length=20)
	private String name;
	
	@Column(name="price",length=20)
	private double price;

	
	
	public Book() 
	{
		super();
	}



	public Book(int isbn, String name, double price) 
	{
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
	}



	public int getIsbn() 
	{
		return isbn;
	}



	public void setIsbn(int isbn) 
	{
		this.isbn = isbn;
	}



	public String getName()
	{
		return name;
	}



	public void setName(String name)
	{
		this.name = name;
	}



	public double getPrice()
	{
		return price;
	}



	public void setPrice(double price)
	{
		this.price = price;
	}



	@Override
	public String toString()
	{
		return "Book [isbn=" + isbn + ", name=" + name + ", price=" + price + "]";
	}

	

}
