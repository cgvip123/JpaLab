package com.cg_vip.ems.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil 
{
	private static EntityManagerFactory emf = null;
	private static EntityManager em = null;
	
	
	public static EntityManager geEntityManager()
	{
		emf= Persistence.createEntityManagerFactory("Oracle-JPA-PU"); // Provides entity manager
		em = emf.createEntityManager(); //entity manager takes care of connection
		return em;
		
	}
}
