package com.cg_vip.ems.service;

import java.util.ArrayList;

import com.cg_vip.ems.dao.BookDaoImpl;
import com.cg_vip.ems.dao.IBookDao;
import com.cg_vip.ems.dto.Book;

public class BookServiceImpl implements IBookService
{
	IBookDao iBookDao = new BookDaoImpl();

	@Override
	public ArrayList<Book> getBook() 
	{
		return iBookDao.getBook();
	}

	@Override
	public ArrayList<Book> getBookByAuthorName(String auth_name) 
	{
		
		return iBookDao.getBookByAuthorName(auth_name);
	}

	@Override
	public ArrayList<Book> getBookByPriceRange(double min,double max) 
	{
		
		return iBookDao.getBookByPriceRange(min, max);
	}

	@Override
	public void addBook() {
		iBookDao.addBook();
		
	}

	
 	
	
}
