package com.cg_vip.ems.service;

import java.util.ArrayList;

import com.cg_vip.ems.dto.Book;

public interface IBookService 
{
	public void addBook() ;
	public ArrayList<Book> getBook();
	public ArrayList<Book> getBookByAuthorName(String auth_name);
	public ArrayList<Book> getBookByPriceRange(double min,double max);
}
